/*******************************************************************************
* File Name: SCL_intr.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_SCL_intr_H)
#define CY_ISR_SCL_intr_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void SCL_intr_Start(void);
void SCL_intr_StartEx(cyisraddress address);
void SCL_intr_Stop(void);

CY_ISR_PROTO(SCL_intr_Interrupt);

void SCL_intr_SetVector(cyisraddress address);
cyisraddress SCL_intr_GetVector(void);

void SCL_intr_SetPriority(uint8 priority);
uint8 SCL_intr_GetPriority(void);

void SCL_intr_Enable(void);
uint8 SCL_intr_GetState(void);
void SCL_intr_Disable(void);

void SCL_intr_SetPending(void);
void SCL_intr_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the SCL_intr ISR. */
#define SCL_intr_INTC_VECTOR            ((reg32 *) SCL_intr__INTC_VECT)

/* Address of the SCL_intr ISR priority. */
#define SCL_intr_INTC_PRIOR             ((reg32 *) SCL_intr__INTC_PRIOR_REG)

/* Priority of the SCL_intr interrupt. */
#define SCL_intr_INTC_PRIOR_NUMBER      SCL_intr__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable SCL_intr interrupt. */
#define SCL_intr_INTC_SET_EN            ((reg32 *) SCL_intr__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the SCL_intr interrupt. */
#define SCL_intr_INTC_CLR_EN            ((reg32 *) SCL_intr__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the SCL_intr interrupt state to pending. */
#define SCL_intr_INTC_SET_PD            ((reg32 *) SCL_intr__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the SCL_intr interrupt. */
#define SCL_intr_INTC_CLR_PD            ((reg32 *) SCL_intr__INTC_CLR_PD_REG)



#endif /* CY_ISR_SCL_intr_H */


/* [] END OF FILE */
